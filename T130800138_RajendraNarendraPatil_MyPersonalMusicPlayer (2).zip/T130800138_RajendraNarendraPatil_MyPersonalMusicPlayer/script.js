class MusicPlayer {
    constructor() {
        this.songs = [
            { src: 'songs/1.mp3', title: 'Believer', artist: 'Imagine Dragons', cover: 'covers/cover1.jpeg', favorite: false, duration: '3:24' },
            { src: 'songs/2.mp3', title: 'Bones', artist: 'Imagine Dragons', cover: 'covers/cover2.jpeg', favorite: false, duration: '2:46' },
            { src: 'songs/3.mp3', title: 'Enemy', artist: 'Imagine Dragons', cover: 'covers/cover3.jpeg', favorite: false, duration: '2:53' },
            { src: 'songs/4.mp3', title: 'Thunder', artist: 'Imagine Dragons', cover: 'covers/cover4.jpeg', favorite: false, duration: '3:07' },
            { src: 'songs/5.mp3', title: 'Radioactive', artist: 'Imagine Dragons', cover: 'covers/cover5.jpeg', favorite: false, duration: '3:06' },
            { src: 'songs/6.mp3', title: 'Demons', artist: 'Imagine Dragons', cover: 'covers/cover6.jpeg', favorite: false, duration: '2:57' },
            { src: 'songs/7.mp3', title: 'Natural', artist: 'Imagine Dragons', cover: 'covers/cover7.jpeg', favorite: false, duration: '3:09' },
            { src: 'songs/8.mp3', title: 'Whatever It Takes', artist: 'Imagine Dragons', cover: 'covers/cover8.jpeg', favorite: false, duration: '3:21' }
        ];

        this.currentIndex = 0;
        this.isPlaying = false;
        this.isShuffling = false;
        this.repeatMode = 'none';
        this.recentlyPlayed = JSON.parse(localStorage.getItem('recentlyPlayed')) || [];

        this.initializeElements();
        this.bindEvents();
        this.loadSong(this.currentIndex);
        this.renderPlaylist();
        this.updateRecentlyPlayed();
        this.updateFavorites();
        this.loadFavorites();
        this.updateVisitorCounter();
    }

    initializeElements() {
        this.audio = document.getElementById('audio');
        this.playPauseBtn = document.getElementById('play-pause');
        this.prevBtn = document.getElementById('prev');
        this.nextBtn = document.getElementById('next');
        this.shuffleBtn = document.getElementById('shuffle');
        this.repeatBtn = document.getElementById('repeat');
        this.seekBar = document.getElementById('seek-bar');
        this.currentTimeEl = document.getElementById('current-time');
        this.totalDurationEl = document.getElementById('total-duration');
        this.volumeSlider = document.getElementById('volume');
        this.albumArt = document.getElementById('player-album-art');
        this.songTitle = document.getElementById('player-song-title');
        this.songArtist = document.getElementById('player-song-artist');
        this.currentFavoriteToggle = document.getElementById('current-favorite-toggle');
        this.playlistEl = document.getElementById('playlist');
        this.favoritesEl = document.getElementById('favorites');
        this.sidebarRecentEl = document.getElementById('sidebar-recent');
        this.searchBar = document.getElementById('search-bar');
        this.voiceSearchBtn = document.getElementById('voice-search');
        this.visitorCountEl = document.getElementById('visitor-count');
    }

    bindEvents() {
        this.playPauseBtn.addEventListener('click', () => this.togglePlayPause());
        this.prevBtn.addEventListener('click', () => this.prevSong());
        this.nextBtn.addEventListener('click', () => this.nextSong());
        this.shuffleBtn.addEventListener('click', () => this.toggleShuffle());
        this.repeatBtn.addEventListener('click', () => this.toggleRepeat());
        this.audio.addEventListener('timeupdate', () => this.updateProgress());
        this.audio.addEventListener('ended', () => this.handleSongEnd());
        this.audio.addEventListener('loadedmetadata', () => this.updateDuration());
        this.seekBar.addEventListener('input', () => this.seek());
        this.volumeSlider.addEventListener('input', () => this.updateVolume());
        this.currentFavoriteToggle.addEventListener('click', () => this.toggleCurrentFavorite());
        this.searchBar.addEventListener('input', () => this.searchSongs());
        this.voiceSearchBtn.addEventListener('click', () => this.voiceSearch());
    }

    loadSong(index) {
        if (index < 0 || index >= this.songs.length) return;
        
        const song = this.songs[index];
        this.audio.src = song.src;
        this.albumArt.src = song.cover;
        this.songTitle.textContent = song.title;
        this.songArtist.textContent = song.artist;
        this.currentIndex = index;
        
        this.updateCurrentFavoriteButton();
        this.updatePlaylistHighlight();
    }

    togglePlayPause() {
        if (this.isPlaying) {
            this.pauseSong();
        } else {
            this.playSong();
        }
    }

    playSong() {
        this.audio.play();
        this.isPlaying = true;
        this.playPauseBtn.textContent = '⏸';
        this.addToRecentlyPlayed(this.songs[this.currentIndex]);
    }

    pauseSong() {
        this.audio.pause();
        this.isPlaying = false;
        this.playPauseBtn.textContent = '▶';
    }

    prevSong() {
        if (this.isShuffling) {
            this.currentIndex = Math.floor(Math.random() * this.songs.length);
        } else {
            this.currentIndex = (this.currentIndex - 1 + this.songs.length) % this.songs.length;
        }
        this.loadSong(this.currentIndex);
        if (this.isPlaying) this.playSong();
    }

    nextSong() {
        if (this.isShuffling) {
            this.currentIndex = Math.floor(Math.random() * this.songs.length);
        } else {
            this.currentIndex = (this.currentIndex + 1) % this.songs.length;
        }
        this.loadSong(this.currentIndex);
        if (this.isPlaying) this.playSong();
    }

    toggleShuffle() {
        this.isShuffling = !this.isShuffling;
        this.shuffleBtn.classList.toggle('active', this.isShuffling);
    }

    toggleRepeat() {
        const modes = ['none', 'all', 'one'];
        const currentIndex = modes.indexOf(this.repeatMode);
        this.repeatMode = modes[(currentIndex + 1) % modes.length];
        this.repeatBtn.classList.toggle('active', this.repeatMode !== 'none');
        this.repeatBtn.textContent = this.repeatMode === 'one' ? '🔂' : '🔁';
    }

    handleSongEnd() {
        switch(this.repeatMode) {
            case 'one':
                this.playSong();
                break;
            case 'all':
                this.nextSong();
                break;
            default:
                if (this.currentIndex < this.songs.length - 1) {
                    this.nextSong();
                } else {
                    this.pauseSong();
                }
        }
    }

    updateProgress() {
        const progress = (this.audio.currentTime / this.audio.duration) * 100 || 0;
        this.seekBar.value = progress;
        this.currentTimeEl.textContent = this.formatTime(this.audio.currentTime);
    }

    updateDuration() {
        this.totalDurationEl.textContent = this.formatTime(this.audio.duration);
    }

    seek() {
        this.audio.currentTime = (this.seekBar.value / 100) * this.audio.duration;
    }

    updateVolume() {
        this.audio.volume = this.volumeSlider.value;
    }

    formatTime(seconds) {
        if (isNaN(seconds)) return '0:00';
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    }

    renderPlaylist(filteredSongs = this.songs) {
        this.playlistEl.innerHTML = '';
        filteredSongs.forEach((song, index) => {
            const li = document.createElement('li');
            li.className = 'track-item';
            li.innerHTML = `
                <div class="track-number">${index + 1}</div>
                <div class="track-info">
                    <img src="${song.cover}" alt="${song.title}">
                    <div class="track-details">
                        <div class="track-name">${song.title}</div>
                        <div class="track-artist">${song.artist}</div>
                    </div>
                </div>
                <div class="track-artist">${song.artist}</div>
                <div class="track-duration">${song.duration}</div>
                <div class="track-favorite ${song.favorite ? 'favorited' : ''}" data-index="${this.songs.indexOf(song)}">♥</div>
            `;

            li.addEventListener('click', (e) => {
                if (!e.target.closest('.track-favorite')) {
                    this.currentIndex = this.songs.indexOf(song);
                    this.loadSong(this.currentIndex);
                    this.playSong();
                }
            });

            const favoriteBtn = li.querySelector('.track-favorite');
            favoriteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const songIndex = parseInt(e.target.dataset.index);
                this.toggleFavorite(songIndex);
            });

            this.playlistEl.appendChild(li);
        });
    }

    updatePlaylistHighlight() {
        const items = this.playlistEl.querySelectorAll('.track-item');
        items.forEach((item, index) => {
            item.classList.toggle('playing', index === this.currentIndex);
        });
    }

    toggleCurrentFavorite() {
        this.toggleFavorite(this.currentIndex);
    }

    toggleFavorite(index) {
        this.songs[index].favorite = !this.songs[index].favorite;
        this.updateCurrentFavoriteButton();
        this.updateFavorites();
        this.renderPlaylist();
        this.saveFavorites();
    }

    updateCurrentFavoriteButton() {
        const currentSong = this.songs[this.currentIndex];
        this.currentFavoriteToggle.textContent = currentSong.favorite ? '♥' : '♡';
        this.currentFavoriteToggle.classList.toggle('favorited', currentSong.favorite);
    }

    addToRecentlyPlayed(song) {
        this.recentlyPlayed = this.recentlyPlayed.filter(s => s.title !== song.title);
        this.recentlyPlayed.unshift({...song});
        if (this.recentlyPlayed.length > 10) {
            this.recentlyPlayed.pop();
        }
        this.updateRecentlyPlayed();
        localStorage.setItem('recentlyPlayed', JSON.stringify(this.recentlyPlayed));
    }

    updateRecentlyPlayed() {
        this.sidebarRecentEl.innerHTML = '';
        this.recentlyPlayed.slice(0, 5).forEach(song => {
            const li = document.createElement('li');
            li.textContent = `${song.title} - ${song.artist}`;
            li.addEventListener('click', () => {
                this.currentIndex = this.songs.findIndex(s => s.title === song.title);
                this.loadSong(this.currentIndex);
                this.playSong();
            });
            this.sidebarRecentEl.appendChild(li);
        });
    }

    updateFavorites() {
        const favSongs = this.songs.filter(s => s.favorite);
        this.favoritesEl.innerHTML = '';
        favSongs.forEach(song => {
            const li = document.createElement('li');
            li.innerHTML = `
                <img src="${song.cover}" alt="${song.title}">
                <div class="track-name">${song.title}</div>
                <div class="track-artist">${song.artist}</div>
            `;
            li.addEventListener('click', () => {
                this.currentIndex = this.songs.findIndex(s => s.title === song.title);
                this.loadSong(this.currentIndex);
                this.playSong();
            });
            this.favoritesEl.appendChild(li);
        });
    }

    saveFavorites() {
        const favoriteStatus = this.songs.map(s => s.favorite);
        localStorage.setItem('favoriteStatus', JSON.stringify(favoriteStatus));
    }

    loadFavorites() {
        const favoriteStatus = JSON.parse(localStorage.getItem('favoriteStatus'));
        if (favoriteStatus) {
            this.songs.forEach((song, index) => {
                song.favorite = favoriteStatus[index] || false;
            });
        }
    }

    searchSongs() {
        const query = this.searchBar.value.toLowerCase();
        const filtered = this.songs.filter(song => 
            song.title.toLowerCase().includes(query) || 
            song.artist.toLowerCase().includes(query)
        );
        this.renderPlaylist(filtered);
    }

    voiceSearch() {
        if (!('webkitSpeechRecognition' in window)) {
            alert('Voice search not supported in your browser.');
            return;
        }

        const recognition = new webkitSpeechRecognition();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.start();

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript.toLowerCase();
            this.searchBar.value = transcript;
            this.searchSongs();
        };

        recognition.onerror = () => {
            alert('Voice search failed. Please try again.');
        };
    }

    
}

// Initialize the music player when page loads
document.addEventListener('DOMContentLoaded', () => {
    new MusicPlayer();
});
